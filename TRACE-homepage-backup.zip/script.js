(function () {
  'use strict';

  var TRACE_LINE_URL = 'https://lin.ee/Y4Hz0uT';
  var TRACE_INSTAGRAM_URL = 'https://www.instagram.com/trace_saga?igsh=OHkyYmZuZ2JwMmVj&utm_source=qr';

  var header = document.getElementById('header');
  var menuBtn = document.getElementById('menuBtn');
  var nav = document.getElementById('nav');
  var floatLine = document.getElementById('floatLine');
  var navLinks = document.querySelectorAll('.nav__link[data-nav]');
  var revealElements = document.querySelectorAll('.reveal');
  var lineLinks = document.querySelectorAll('.js-line-reserve');
  var instagramLinks = document.querySelectorAll('.js-instagram');

  var scrollThreshold = 20;
  var lastScrollY = 0;
  var isMenuOpen = false;
  var prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function handleScroll() {
    var currentScrollY = window.scrollY;

    if (header) {
      header.classList.toggle('is-scrolled', currentScrollY > scrollThreshold);

      if (!isMenuOpen && currentScrollY > 400) {
        header.classList.toggle('is-hidden', currentScrollY > lastScrollY && currentScrollY > 500);
      } else {
        header.classList.remove('is-hidden');
      }
    }

    if (floatLine) {
      var footer = document.querySelector('.footer');
      var hideFloat = false;

      if (footer) {
        hideFloat = footer.getBoundingClientRect().top < window.innerHeight;
      }

      floatLine.classList.toggle('is-hidden', hideFloat);
    }

    lastScrollY = currentScrollY;
  }

  function openMenu() {
    isMenuOpen = true;
    menuBtn.classList.add('is-active');
    nav.classList.add('is-open');
    menuBtn.setAttribute('aria-expanded', 'true');
    menuBtn.setAttribute('aria-label', 'メニューを閉じる');
    document.body.style.overflow = 'hidden';
    header.classList.remove('is-hidden');
  }

  function closeMenu() {
    isMenuOpen = false;
    menuBtn.classList.remove('is-active');
    nav.classList.remove('is-open');
    menuBtn.setAttribute('aria-expanded', 'false');
    menuBtn.setAttribute('aria-label', 'メニューを開く');
    document.body.style.overflow = '';
  }

  function toggleMenu() {
    if (isMenuOpen) {
      closeMenu();
    } else {
      openMenu();
    }
  }

  function initMenu() {
    if (!menuBtn || !nav) return;

    menuBtn.addEventListener('click', toggleMenu);

    navLinks.forEach(function (link) {
      link.addEventListener('click', closeMenu);
    });

    document.querySelectorAll('.nav__reserve').forEach(function (link) {
      link.addEventListener('click', closeMenu);
    });

    window.addEventListener('resize', function () {
      if (window.innerWidth >= 768 && isMenuOpen) {
        closeMenu();
      }
    });
  }

  function initExternalLinks() {
    lineLinks.forEach(function (link) {
      link.setAttribute('href', TRACE_LINE_URL);
    });

    instagramLinks.forEach(function (link) {
      link.setAttribute('href', TRACE_INSTAGRAM_URL);
    });
  }

  function initScrollReveal() {
    if (!revealElements.length) return;

    if (!('IntersectionObserver' in window)) {
      revealElements.forEach(function (el) {
        el.classList.add('is-visible');
      });
      return;
    }

    var observer = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            observer.unobserve(entry.target);
          }
        });
      },
      {
        root: null,
        rootMargin: '0px 0px -5% 0px',
        threshold: 0.06
      }
    );

    revealElements.forEach(function (el) {
      if (!el.closest('.hero')) {
        observer.observe(el);
      }
    });
  }

  function initHeroReveal() {
    var heroReveals = document.querySelectorAll('.hero .reveal');

    if (prefersReducedMotion) {
      heroReveals.forEach(function (el) {
        el.classList.add('is-visible');
      });
      return;
    }

    heroReveals.forEach(function (el, index) {
      setTimeout(function () {
        el.classList.add('is-visible');
      }, 160 + index * 90);
    });
  }

  function initStaggerReveal() {
    var groups = document.querySelectorAll(
      '.feature__grid, .flow__steps, .program__grid, .result__grid, .equipment__grid, .price__grid, .voice__grid'
    );

    groups.forEach(function (group) {
      var items = group.querySelectorAll('.reveal');
      items.forEach(function (item, index) {
        item.style.transitionDelay = (index * 0.08) + 's';
      });
    });
  }

  function initActiveNav() {
    if (!('IntersectionObserver' in window) || !navLinks.length) return;

    var sections = [];

    navLinks.forEach(function (link) {
      var id = link.getAttribute('data-nav');
      var section = document.getElementById(id);
      if (section) sections.push({ id: id, el: section });
    });

    var observer = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            navLinks.forEach(function (link) {
              link.classList.toggle('is-active', link.getAttribute('data-nav') === entry.target.id);
            });
          }
        });
      },
      {
        root: null,
        rootMargin: '-40% 0px -50% 0px',
        threshold: 0
      }
    );

    sections.forEach(function (section) {
      observer.observe(section.el);
    });
  }

  function initSmoothAnchor() {
    document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
      anchor.addEventListener('click', function (event) {
        var targetId = anchor.getAttribute('href');
        if (!targetId || targetId === '#') return;

        var target = document.querySelector(targetId);
        if (!target) return;

        event.preventDefault();
        var headerOffset = header ? header.offsetHeight : 0;
        var targetPosition = target.getBoundingClientRect().top + window.scrollY - headerOffset;

        window.scrollTo({
          top: targetPosition,
          behavior: prefersReducedMotion ? 'auto' : 'smooth'
        });
      });
    });
  }

  function init() {
    initExternalLinks();
    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    initMenu();
    initStaggerReveal();
    initHeroReveal();
    initScrollReveal();
    initActiveNav();
    initSmoothAnchor();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
